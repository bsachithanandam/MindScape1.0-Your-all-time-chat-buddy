package edu.sjsu.android.final_project;

import static androidx.core.content.ContextCompat.getDrawable;

import android.graphics.drawable.Drawable;
import android.media.Image;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.fragment.NavHostFragment;

import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.Timer;
import java.util.TimerTask;

public class quotes extends Fragment {
    public static int count=0;
    Handler m_handler;
    Runnable m_handlerTask ;
    String[] quotes = {"Hello","world","I am IronMan","I am thankful for our small infinity","Hakkuna Matata"};
    public quotes() {
        // Required empty public constructor
    }



    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View view = inflater.inflate(R.layout.fragment_quotes, container, false);
        TextView quote = (TextView) view.findViewById(R.id.quote_text);
        m_handler = new Handler();
        m_handlerTask = new Runnable() {
        int i = 0,j =0;
            @Override
            public void run() {
                // TODO Auto-generated method stub
                if(i<5)
                {
                    quote.setText(quotes[i]);
                    i++;
                }
                else
                {
                    i = 0;
                    m_handler.removeCallbacks(m_handlerTask);
                }
                m_handler.postDelayed(m_handlerTask, 1500);
            }
        };
        m_handlerTask.run();

        return view;
    }
}